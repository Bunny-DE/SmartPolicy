# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC CREATE or REPLACE temp VIEW vw_sales_by_policy_type_and_month as
# MAGIC SELECT 
# MAGIC     policy_type, 
# MAGIC     DATE_FORMAT(start_date, 'yyyy-MM') AS sale_month, 
# MAGIC     SUM(premium) AS total_premium
# MAGIC FROM 
# MAGIC     silverlayer.policy
# MAGIC GROUP BY 
# MAGIC     policy_type, 
# MAGIC     DATE_FORMAT(start_date, 'yyyy-MM')
# MAGIC ORDER BY 
# MAGIC     policy_type, 
# MAGIC     sale_month;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from vw_sales_by_policy_type_and_month

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC merge into goldlayer.sales_by_policy_type_and_month as t using vw_sales_by_policy_type_and_month as s on t.policy_type = s.policy_type and t.sale_month = s.sale_month when matched then update set t.total_premium = s.total_premium,t.updated_timestamp = current_timestamp() when not matched then insert (policy_type,sale_month,total_premium,updated_timestamp) values (s.policy_type,s.sale_month,s.total_premium,current_timestamp());

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from goldlayer.sales_by_policy_type_and_month

# COMMAND ----------

# MAGIC %sql
# MAGIC use database silverlayer;
# MAGIC create or replace temp view vw_claims_by_policy_type_and_month as 
# MAGIC select 
# MAGIC   p.policy_type,
# MAGIC   c.claim_status,
# MAGIC   count(*) as total_claim,
# MAGIC   sum(c.claim_amount) as total_claim_amount
# MAGIC from silverlayer.claim c join silverlayer.policy p on c.policy_id = p.policy_id
# MAGIC group by
# MAGIC   policy_type,
# MAGIC   claim_status having p.policy_type is not null;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from vw_claims_by_policy_type_and_month

# COMMAND ----------

# MAGIC %sql
# MAGIC merge into goldlayer.claims_by_policy_type_and_month as t using vw_claims_by_policy_type_and_month as s on t.policy_type = s.policy_type and t.claim_status = s.claim_status when matched then update set t.total_claims = s.total_claim, t.total_claim_amount = s.total_claim_amount,t.updated_timestamp = current_timestamp() when not matched then insert (policy_type, claim_status, total_claims, total_claim_amount, updated_timestamp) values (s.policy_type, s.claim_status, s.total_claim, s.total_claim_amount, current_timestamp());

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from goldlayer.claims_by_policy_type_and_month

# COMMAND ----------

# MAGIC %sql
# MAGIC use database silverlayer;
# MAGIC create or replace temp view vm_claim_analysis as
# MAGIC select
# MAGIC   policy_type,
# MAGIC   avg(claim_amount) as avg_claim_amount,
# MAGIC   max(claim_amount) as max_claim_amount,
# MAGIC   min(claim_amount) as min_claim_amount,
# MAGIC   count(distinct claim_id) as total_claims
# MAGIC from 
# MAGIC     silverlayer.claim c 
# MAGIC   join silverlayer.policy p on c.policy_id = p.policy_id
# MAGIC group by policy_type having p.policy_type is not null;

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from vm_claim_analysis

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC merge into goldlayer.claims_analysis as t using vm_claim_analysis as s on t.policy_type = s.policy_type when matched then update set t.avg_claim_amount = s.avg_claim_amount, t.max_claim_amount = s.max_claim_amount, t.min_claim_amount = s.min_claim_amount, t.total_claims = s.total_claims, t.updated_timestamp = current_timestamp() when not matched then insert (policy_type, avg_claim_amount, max_claim_amount, min_claim_amount, total_claims, updated_timestamp) values (s.policy_type, s.avg_claim_amount, s.max_claim_amount, s.min_claim_amount, s.total_claims, current_timestamp());

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC select * from goldlayer.claims_analysis

# COMMAND ----------

