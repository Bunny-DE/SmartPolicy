# Databricks notebook source

df = spark.sql("SELECT * from bronzelayer.branch where branch_id is not null and merge_flag = FALSE")
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC Remove all the leading and trailing spaces in branch_country and do it uppercase

# COMMAND ----------

from pyspark.sql.functions import *
df = spark.sql("SELECT b.branch_id, b.branch_city, upper(trim(b.branch_country)) as branch_country from bronzelayer.branch b  where branch_id is not null and merge_flag = FALSE")
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC merge into silver layer table

# COMMAND ----------

from pyspark.sql.functions import *
df.createOrReplaceTempView('clean_branch')
spark.sql("merge into silverlayer.branch as t using clean_branch as s on t.branch_id = s.branch_id when matched then update set t.branch_country = s.branch_country,t.branch_city = s.branch_city,t.merged_timestamp = current_timestamp() when not matched then insert (branch_id,branch_country,branch_city,merged_timestamp) values(s.branch_id,s.branch_country,s.branch_city,current_timestamp())")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from silverlayer.branch

# COMMAND ----------

# MAGIC %sql
# MAGIC update bronzelayer.branch set merge_flag = true where merge_flag = false