# Databricks notebook source
df = spark.sql("SELECT c.claim_id, c.claim_amount, c.LastUpdatedTimeStamp, c.policy_id, c.claim_status, to_date(date_format(c.date_of_claim, 'MM-dd-yyyy'), 'MM-dd-yyyy') as date_of_claim from bronzelayer.claim c INNER JOIN bronzelayer.policy p ON c.policy_id = p.policy_id  WHERE c.claim_amount  is not null and c.claim_id is not null and c.policy_id is not null and c.claim_status is not null and c.LastUpdatedTimeStamp is not null and c.merge_flag = FALSE and c.claim_amount >0")
display(df)

# COMMAND ----------

from pyspark.sql.functions import *
df.createOrReplaceTempView("clean_claim")
spark.sql("MERGE INTO silverlayer.Claim AS T USING clean_claim AS S ON t.claim_id = s.claim_id WHEN MATCHED then UPDATE SET t.claim_amount = s.claim_amount,t.LastUpdatedTimeStamp = s.LastUpdatedTimeStamp, t.claim_status = s.claim_status,t.date_of_claim = s.date_of_claim,t.merged_timestamp = current_timestamp() WHEN not MATCHED THEN INSERT (claim_id,claim_amount, LastUpdatedTimeStamp, policy_id, claim_status, date_of_claim,merged_timestamp ) VALUES (s.claim_id, s.claim_amount, s.LastUpdatedTimeStamp, s.policy_id, s.claim_status, s.date_of_claim,current_timestamp())")

# COMMAND ----------

spark.sql(" UPDATE bronzelayer.claim set merge_flag = TRUE where merge_flag = FALSE")