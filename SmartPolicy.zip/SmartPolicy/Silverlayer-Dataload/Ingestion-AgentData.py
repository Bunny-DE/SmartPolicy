# Databricks notebook source
df = spark.sql("select * from bronzelayer.agent where merge_flag = False")
#display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC Remove all rows where branchid not exists in branch table from agent table
# MAGIC

# COMMAND ----------

df = spark.sql("SELECT a.* FROM bronzelayer.agent a INNER JOIN bronzelayer.branch b on  a.branch_id = b.branch_id where a.merge_flag = FALSE ")

display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC phone have 10 digit phone number

# COMMAND ----------

df = spark.sql("SELECT a.* FROM bronzelayer.agent a INNER JOIN bronzelayer.branch b on  a.branch_id = b.branch_id where a.merge_flag = FALSE and length(a.agent_phone)=10")

display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC Replace all null emails with smartpolicy@gmail.**com**

# COMMAND ----------

df.createOrReplaceTempView("agent_temp")
df_email = spark.sql("select a.agent_id, a.agent_name, a.agent_phone, a.branch_id,a.create_timestamp, regexp_replace(a.agent_email, '', 'smartpolicy@gmail.com') as project_email from agent_temp a where a.agent_email =''  UNION  select  a.agent_id, a.agent_name, a.agent_phone, a.branch_id,a.create_timestamp, agent_email from agent_temp a where a.agent_email !='' ")

display(df_email)


# COMMAND ----------

# MAGIC %md
# MAGIC add the merged date timestamp

# COMMAND ----------

from pyspark.sql.functions import current_timestamp
df_final = df_email.withColumn("merged_timestamp",current_timestamp())
display(df_final)

# COMMAND ----------

df_email.createOrReplaceTempView("clean_agent")

spark.sql(" MERGE INTO silverlayer.agent AS T USING clean_agent AS S ON  t.agent_id = s.agent_id  WHEN MATCHED THEN UPDATE SET t.agent_phone = s.agent_phone, t.agent_email = s.project_email, t.agent_name = s.agent_name, t.branch_id= s.branch_id, t.create_Timestamp = s.create_TimeStamp, T.merged_timestamp  =  current_timestamp() When not matched then INSERT (agent_phone, agent_email , agent_name, branch_id ,create_Timestamp , merged_timestamp, agent_id ) values (s.agent_phone, s.project_email , s.agent_name, s.branch_id ,s.create_Timestamp , current_timestamp(), s.agent_id)")

spark.sql("update bronzelayer.agent set merge_flag =True WHERE merge_flag = false")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from silverlayer.agent