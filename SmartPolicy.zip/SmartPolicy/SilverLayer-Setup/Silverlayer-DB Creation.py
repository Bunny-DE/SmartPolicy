# Databricks notebook source
# MAGIC %sql
# MAGIC select current_database()

# COMMAND ----------

# MAGIC %sql
# MAGIC create database silverlayer;

# COMMAND ----------

# MAGIC %sql
# MAGIC use silverlayer;
# MAGIC show tables;